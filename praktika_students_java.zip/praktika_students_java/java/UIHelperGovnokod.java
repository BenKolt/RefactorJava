// UIHelperGovnokod.java - без изменений
import java.util.List;
import java.io.File;

public class UIHelperGovnokod {
    private static final int LINE_WIDTH = 76;
    private static final int NAME_DISPLAY_LENGTH = 36;
    private static final int DECORATIVE_LINE_LENGTH = 10;

    public static void printBorder(String title) {
        printHorizontalLine("=");

        if (title != null && !title.trim().isEmpty()) {
            printCenteredTitle(title);
            printHorizontalLine("=");
        }

        printDecorativeLine();
    }

    private static void printHorizontalLine(String character) {
        System.out.print("  ");
        for (int i = 0; i < LINE_WIDTH; i++) {
            System.out.print(character);
        }
        System.out.println();
    }

    private static void printCenteredTitle(String title) {
        int padding = (LINE_WIDTH - title.length()) / 2;
        System.out.print("  |");

        for (int i = 0; i < padding; i++) {
            System.out.print(" ");
        }

        System.out.print(title);

        int totalSpaces = LINE_WIDTH - padding - title.length();
        for (int i = 0; i < totalSpaces; i++) {
            System.out.print(" ");
        }

        System.out.println("|");
    }

    private static void printDecorativeLine() {
        System.out.print("  ");
        for (int i = 0; i < DECORATIVE_LINE_LENGTH; i++) {
            System.out.print("~");
        }
        System.out.println();
    }

    public static void printSeparator() {
        printHorizontalLine("-");
    }

    public static void printFileTableHeader() {
        System.out.print("  " + String.format("%-4s", "N"));
        System.out.print(String.format("%-40s", "Name"));
        System.out.print(String.format("%-15s", "Size"));
        System.out.println("Type");
        printSeparator();
    }

    public static void printFileRow(int index, String name, boolean isDir, long size) {
        System.out.print("  " + String.format("%-4s", index));

        String displayName = formatFileName(name);
        System.out.print(String.format("%-40s", displayName));

        if (isDir) {
            System.out.print(String.format("%-15s", "-"));
            System.out.println("Folder");
        } else {
            String sizeStr = formatFileSize(size);
            System.out.print(String.format("%-15s", sizeStr));
            System.out.println("File");
        }
    }

    private static String formatFileName(String name) {
        if (name.length() > NAME_DISPLAY_LENGTH) {
            return name.substring(0, NAME_DISPLAY_LENGTH - 3) + "...";
        }
        return name;
    }

    private static String formatFileSize(long size) {
        if (size < 1024) {
            return size + " B";
        } else if (size < 1024 * 1024) {
            return String.format("%.1f KB", size / 1024.0);
        } else {
            return String.format("%.1f MB", size / (1024.0 * 1024.0));
        }
    }

    public static void displayMainMenu() {
        printBorder("MAIN MENU");

        System.out.println("  1.  Read file");
        System.out.println("  2.  Edit file");
        System.out.println("  3.  Save file");
        System.out.println("  4.  Search in file");
        System.out.println("  5.  Delete file");
        System.out.println("  6.  Create new file");
        System.out.println("  7.  Go to folder");
        System.out.println("  8.  Copy file");
        System.out.println("  9.  Rename file");
        System.out.println("  10. File analysis");
        System.out.println("  11. Backup");
        printSeparator();
        System.out.println("  99. Exit");
        printBorder("");

        printEmojiBanner();
    }

    static void printEmojiBanner() {
        System.out.println("  (╯°□°）╯︵ ┻━┻");
    }

    public static void displayFileList(String currentDirectory, List<String> files) {
        printBorder("SODERZHIMOE KATALOGA");
        System.out.println("  Path: " + currentDirectory);
        System.out.println("  Elements: " + files.size());
        printSeparator();

        if (files.isEmpty()) {
            System.out.println("  Folder is empty");
            printSeparator();
            return;
        }

        printFileTableHeader();

        for (int i = 0; i < files.size(); i++) {
            String filePath = currentDirectory + File.separator + files.get(i);
            File file = new File(filePath);
            boolean isDir = file.isDirectory();
            long size = 0;

            if (!isDir && file.exists()) {
                size = file.length();
            }

            printFileRow(i + 1, files.get(i), isDir, size);
        }

        printSeparator();
    }
}