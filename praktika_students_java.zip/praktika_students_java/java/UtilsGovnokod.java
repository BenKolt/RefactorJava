// UtilsGovnokod.java - без изменений
import java.io.*;
import java.util.*;

public class UtilsGovnokod {
    public static void performBubbleSortGovnokod(List<String> arr) {
        if (arr == null || arr.size() <= 1) {
            return;
        }
        Collections.sort(arr, String.CASE_INSENSITIVE_ORDER);
    }

    public static void analyzeFilePropertiesGovnokod(String filepath) {
        try {
            clearScreen();
            UIHelperGovnokod.printBorder("FILE ANALYSIS");

            File file = new File(filepath);
            if (!file.exists()) {
                System.out.println("  File not found!");
                return;
            }

            FileInfo fileInfo = analyzeFile(file);
            displayFileInfo(fileInfo);

        } catch (IOException e) {
            System.out.println("  Error analyzing file: " + e.getMessage());
        }
    }

    private static FileInfo analyzeFile(File file) throws IOException {
        FileInfo info = new FileInfo();
        info.name = file.getName();
        info.size = file.length();
        info.lines = 0;
        info.lastModified = new Date(file.lastModified());

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            while (reader.readLine() != null) {
                info.lines++;
            }
        }

        return info;
    }

    private static void displayFileInfo(FileInfo info) {
        System.out.println("  Name: " + info.name);
        System.out.println("  Size: " + info.size + " bytes");
        System.out.println("  Lines: " + info.lines);
        System.out.println("  Last modified: " + info.lastModified);
        UIHelperGovnokod.printSeparator();
    }

    private static class FileInfo {
        String name;
        long size;
        int lines;
        Date lastModified;
    }

    private static void clearScreen() {
        System.out.print("\033[H\033[2J");
        System.out.flush();
    }
}