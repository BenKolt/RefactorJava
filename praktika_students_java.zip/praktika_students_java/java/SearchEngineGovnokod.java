// SearchEngineGovnokod.java - изменен для работы с параметрами
import java.util.*;

public class SearchEngineGovnokod {
    public static void searchInFileGovnokod(String buffer, String query, List<String> searchResults) {
        if (buffer == null || buffer.isEmpty()) {
            System.out.println("\n  Open file first!");
            return;
        }

        if (query == null || query.trim().isEmpty()) {
            System.out.println("\n  Empty query!");
            return;
        }

        searchResults.clear();
        List<Integer> positions = findOccurrences(buffer, query);

        for (Integer pos : positions) {
            searchResults.add(pos.toString());
        }

        displaySearchResults(query, positions);
    }

    private static List<Integer> findOccurrences(String text, String query) {
        List<Integer> positions = new ArrayList<>();
        int index = 0;

        while ((index = text.indexOf(query, index)) != -1) {
            positions.add(index);
            index += query.length();
        }

        return positions;
    }

    private static void displaySearchResults(String query, List<Integer> positions) {
        clearScreen();
        UIHelperGovnokod.printBorder("SEARCH RESULTS");
        System.out.println("  Query: '" + query + "'");
        System.out.println("  Found: " + positions.size());
        UIHelperGovnokod.printSeparator();

        if (positions.isEmpty()) {
            System.out.println("  Not found");
        } else {
            int limit = Math.min(positions.size(), 20);
            for (int i = 0; i < limit; i++) {
                System.out.println("  " + (i + 1) + ". Position " + positions.get(i));
            }

            if (positions.size() > limit) {
                System.out.println("  ... and " + (positions.size() - limit) + " more");
            }
        }
        UIHelperGovnokod.printSeparator();
    }

    private static void clearScreen() {
        System.out.print("\033[H\033[2J");
        System.out.flush();
    }
}