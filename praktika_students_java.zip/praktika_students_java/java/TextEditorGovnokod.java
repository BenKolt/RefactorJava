// TextEditorGovnokod.java - изменен для работы с параметрами
import java.io.*;
import java.util.Scanner;

public class TextEditorGovnokod {
    public static void readFileGovnokod(String filename) {
        try {
            String content = readFileContent(filename);

            // Note: нужно вернуть состояние вызывающему коду
            System.out.println("\n  File loaded successfully: " + filename);
            System.out.println("  Size: " + content.length() + " bytes");

            clearScreen();
            displayFileContent(filename, content);

        } catch (IOException e) {
            System.out.println("\n  Error reading file: " + e.getMessage() + "\n");
        }
    }

    private static String readFileContent(String filename) throws IOException {
        StringBuilder content = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                content.append(line).append("\n");
            }
        }
        return content.toString();
    }

    private static void displayFileContent(String filename, String content) {
        UIHelperGovnokod.printBorder("FILE CONTENT");
        System.out.println("  File: " + filename);
        System.out.println("  Size: " + content.length() + " bytes");
        UIHelperGovnokod.printSeparator();
        System.out.print(content);
        UIHelperGovnokod.printSeparator();
    }

    public static void editFileGovnokod(String currentEditFile, String editorBuffer) {
        if (currentEditFile == null || currentEditFile.isEmpty()) {
            System.out.println("\n  Open file first!");
            return;
        }

        clearScreen();
        UIHelperGovnokod.printBorder("EDIT FILE");
        System.out.println("  File: " + currentEditFile);
        System.out.println("  Current size: " + (editorBuffer != null ? editorBuffer.length() : 0) + " bytes");
        UIHelperGovnokod.printSeparator();
        System.out.println("\n  Enter new content (EOF on new line to finish):");
        UIHelperGovnokod.printSeparator();

        String newContent = readUserInput();
        System.out.println("\n  Content modified (not saved)! New size: " + newContent.length() + " bytes");
    }

    private static String readUserInput() {
        Scanner scanner = new Scanner(System.in);
        StringBuilder content = new StringBuilder();
        String line;

        while (scanner.hasNextLine()) {
            line = scanner.nextLine();
            if (line.equals("EOF")) {
                break;
            }
            content.append(line).append("\n");
        }

        return content.toString();
    }

    public static void saveFileGovnokod(String currentEditFile, String editorBuffer) {
        if (currentEditFile == null || currentEditFile.isEmpty()) {
            System.out.println("\n  No open file!");
            return;
        }

        if (editorBuffer == null) {
            System.out.println("\n  Nothing to save!");
            return;
        }

        clearScreen();
        UIHelperGovnokod.printBorder("SAVE FILE");
        System.out.println("  File: " + currentEditFile);
        System.out.println("  Size: " + editorBuffer.length() + " bytes");
        UIHelperGovnokod.printSeparator();

        try {
            saveFileContent(currentEditFile, editorBuffer);
            System.out.println("  File saved successfully!");
        } catch (IOException e) {
            System.out.println("  Error saving file: " + e.getMessage());
        }
    }

    private static void saveFileContent(String filename, String content) throws IOException {
        try (FileWriter writer = new FileWriter(filename)) {
            writer.write(content);
        }
    }

    public static void createBackupGovnokod(String currentEditFile, String editorBuffer) {
        if (currentEditFile == null || currentEditFile.isEmpty()) {
            System.out.println("\n  No open file!");
            return;
        }

        if (editorBuffer == null) {
            System.out.println("\n  Nothing to backup!");
            return;
        }

        clearScreen();
        UIHelperGovnokod.printBorder("CREATE BACKUP");
        System.out.println("  File: " + currentEditFile);
        UIHelperGovnokod.printSeparator();

        try {
            String backupName = currentEditFile + ".backup";
            saveFileContent(backupName, editorBuffer);
            System.out.println("  Backup created: " + backupName);
        } catch (IOException e) {
            System.out.println("  Error creating backup: " + e.getMessage());
        }
    }

    private static void clearScreen() {
        System.out.print("\033[H\033[2J");
        System.out.flush();
    }
}