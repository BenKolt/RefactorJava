// FileManagerGovnokod.java - без изменений
import java.io.*;
import java.nio.file.*;

public class FileManagerGovnokod {
    private static final int BUFFER_SIZE = 8192;

    public static void deleteFileGovnokod(String filepath) {
        try {
            boolean deleted = Files.deleteIfExists(Paths.get(filepath));
            if (deleted) {
                System.out.println("\n  File deleted!");
            } else {
                System.out.println("\n  File not found!");
            }
        } catch (IOException e) {
            System.out.println("\n  Error deleting file: " + e.getMessage() + "\n");
        }
    }

    public static void copyFileGovnokod(String source, String dest) {
        try {
            copyFileWithBuffer(source, dest);
            System.out.println("\n  File copied!");
        } catch (IOException e) {
            System.out.println("\n  Error: cannot copy file - " + e.getMessage() + "\n");
        }
    }

    private static void copyFileWithBuffer(String source, String dest) throws IOException {
        try (InputStream fis = new FileInputStream(source);
             OutputStream fos = new FileOutputStream(dest)) {
            byte[] buffer = new byte[BUFFER_SIZE];
            int bytesRead;
            while ((bytesRead = fis.read(buffer)) != -1) {
                fos.write(buffer, 0, bytesRead);
            }
        }
    }

    public static void renameFileGovnokod(String oldPath, String newPath) {
        try {
            Path source = Paths.get(oldPath);
            Path target = Paths.get(newPath);
            Files.move(source, target, StandardCopyOption.REPLACE_EXISTING);
            System.out.println("  File renamed!");
        } catch (IOException e) {
            System.out.println("  Error renaming file: " + e.getMessage());
        }
    }

    public static void createFileGovnokod(String filepath) {
        try {
            boolean created = new File(filepath).createNewFile();
            if (created) {
                System.out.println("  File created!");
            } else {
                System.out.println("  File already exists!");
            }
        } catch (IOException e) {
            System.out.println("  Error creating file: " + e.getMessage());
        }
    }
}