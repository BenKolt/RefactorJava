// DirtyTextEditorGovnokod.java - переписан с передачей состояния через параметры
import java.util.*;
import java.io.*;

public class DirtyTextEditorGovnokod {

    public static void main(String[] args) {
        System.out.println();

        // Локальные переменные вместо глобальных
        List<String> currentFiles = new ArrayList<>();
        String currentDirectory = ".";
        String currentEditFile = "";
        String editorBuffer = "";
        List<String> searchResults = new ArrayList<>();
        int totalFileReads = 0;
        int totalFileWrites = 0;
        boolean unsavedChanges = false;

        int choice = 0;
        Scanner mainScanner = new Scanner(System.in);

        while (choice != 99) {
            clearScreen();
            refreshFileList(currentDirectory, currentFiles);
            UIHelperGovnokod.displayMainMenu();

            System.out.print("\n  Ваш выбор: ");
            try {
                choice = Integer.parseInt(mainScanner.nextLine());
            } catch (NumberFormatException e) {
                choice = -1;
            }

            processUserChoice(choice, mainScanner,
                    currentFiles, currentDirectory,
                    currentEditFile, editorBuffer, searchResults,
                    totalFileReads, totalFileWrites, unsavedChanges);
        }

        mainScanner.close();
        displayExitMessage();
    }

    private static void processUserChoice(int choice, Scanner scanner,
                                          List<String> currentFiles, String currentDirectory,
                                          String currentEditFile, String editorBuffer, List<String> searchResults,
                                          int totalFileReads, int totalFileWrites, boolean unsavedChanges) {
        switch (choice) {
            case 1:
                readFile(scanner, currentFiles, currentDirectory);
                waitForEnter(scanner);
                break;
            case 2:
                TextEditorGovnokod.editFileGovnokod(currentEditFile, editorBuffer);
                break;
            case 3:
                TextEditorGovnokod.saveFileGovnokod(currentEditFile, editorBuffer);
                waitForEnter(scanner);
                break;
            case 4:
                searchInFile(scanner, editorBuffer, searchResults);
                waitForEnter(scanner);
                break;
            case 5:
                deleteFile(scanner, currentFiles, currentDirectory);
                waitForEnter(scanner);
                break;
            case 6:
                createNewFile(scanner, currentDirectory);
                waitForEnter(scanner);
                break;
            case 7:
                navigateDirectory(scanner, currentDirectory);
                break;
            case 8:
                copyFile(scanner, currentFiles, currentDirectory);
                waitForEnter(scanner);
                break;
            case 9:
                renameFile(scanner, currentFiles, currentDirectory);
                waitForEnter(scanner);
                break;
            case 10:
                analyzeFileProperties(scanner, currentFiles, currentDirectory);
                waitForEnter(scanner);
                break;
            case 11:
                TextEditorGovnokod.createBackupGovnokod(currentEditFile, editorBuffer);
                waitForEnter(scanner);
                break;
            case 99:
                break;
            default:
                System.out.println("\n  ❌ Неверный выбор! Попробуйте снова.");
                waitForEnter(scanner);
                break;
        }
    }

    static void refreshFileList(String currentDirectory, List<String> currentFiles) {
        try {
            currentFiles.clear();
            File dir = new File(currentDirectory);
            File[] files = dir.listFiles();

            if (files != null) {
                for (File f : files) {
                    currentFiles.add(f.getName());
                }
            }

            Collections.sort(currentFiles, String.CASE_INSENSITIVE_ORDER);
            UIHelperGovnokod.displayFileList(currentDirectory, currentFiles);

        } catch (Exception e) {
            System.out.println("\n  Error listing files: " + e.getMessage());
        }
    }

    static void readFile(Scanner scanner, List<String> currentFiles, String currentDirectory) {
        if (currentFiles.isEmpty()) {
            System.out.println("\n  Folder is empty!");
            return;
        }

        int fileIndex = getFileChoice(scanner, "Choose file number: ", currentFiles);
        if (fileIndex == -1) return;

        String filename = buildFilePath(currentDirectory, currentFiles.get(fileIndex));
        if (isDirectory(filename)) {
            System.out.println("  This is a folder!");
            return;
        }

        TextEditorGovnokod.readFileGovnokod(filename);
    }

    static void deleteFile(Scanner scanner, List<String> currentFiles, String currentDirectory) {
        if (currentFiles.isEmpty()) {
            System.out.println("\n  No files!");
            return;
        }

        int fileIndex = getFileChoice(scanner, "Choose file number: ", currentFiles);
        if (fileIndex == -1) return;

        String filepath = buildFilePath(currentDirectory, currentFiles.get(fileIndex));
        if (isDirectory(filepath)) {
            System.out.println("  This is a folder!");
            return;
        }

        FileManagerGovnokod.deleteFileGovnokod(filepath);
    }

    static void createNewFile(Scanner scanner, String currentDirectory) {
        System.out.print("\n  Enter filename: ");
        String filename = scanner.nextLine().trim();

        if (filename.isEmpty()) {
            System.out.println("  Empty filename!");
            return;
        }

        String filepath = buildFilePath(currentDirectory, filename);
        FileManagerGovnokod.createFileGovnokod(filepath);
    }

    static void navigateDirectory(Scanner scanner, String currentDirectory) {
        System.out.print("\n  Enter path (.. for parent): ");
        String newdir = scanner.nextLine().trim();

        if (newdir.equals("..")) {
            File currentDir = new File(currentDirectory);
            String parent = currentDir.getParent();
            // Note: нужно изменить currentDirectory в вызывающем коде
            System.out.println("  Use '..' to go to parent directory");
        } else if (!newdir.isEmpty()) {
            String testPath = buildFilePath(currentDirectory, newdir);
            if (new File(testPath).isDirectory()) {
                // Note: нужно изменить currentDirectory в вызывающем коде
                System.out.println("  Changed to: " + testPath);
            } else {
                System.out.println("  Folder not found!");
            }
        }
    }

    static void copyFile(Scanner scanner, List<String> currentFiles, String currentDirectory) {
        if (currentFiles.isEmpty()) {
            System.out.println("\n  No files!");
            return;
        }

        int fileIndex = getFileChoice(scanner, "Choose file number: ", currentFiles);
        if (fileIndex == -1) return;

        String source = buildFilePath(currentDirectory, currentFiles.get(fileIndex));
        if (isDirectory(source)) {
            System.out.println("  This is a folder!");
            return;
        }

        String dest = source + ".copy";
        FileManagerGovnokod.copyFileGovnokod(source, dest);
    }

    static void renameFile(Scanner scanner, List<String> currentFiles, String currentDirectory) {
        if (currentFiles.isEmpty()) {
            System.out.println("\n  No files!");
            return;
        }

        int fileIndex = getFileChoice(scanner, "Choose file number: ", currentFiles);
        if (fileIndex == -1) return;

        System.out.print("  Enter new name: ");
        String newName = scanner.nextLine().trim();

        if (newName.isEmpty()) {
            System.out.println("  Empty filename!");
            return;
        }

        String oldPath = buildFilePath(currentDirectory, currentFiles.get(fileIndex));
        String newPath = buildFilePath(currentDirectory, newName);
        FileManagerGovnokod.renameFileGovnokod(oldPath, newPath);
    }

    static void analyzeFileProperties(Scanner scanner, List<String> currentFiles, String currentDirectory) {
        if (currentFiles.isEmpty()) {
            System.out.println("\n  No files!");
            return;
        }

        int fileIndex = getFileChoice(scanner, "Choose file number: ", currentFiles);
        if (fileIndex == -1) return;

        String filepath = buildFilePath(currentDirectory, currentFiles.get(fileIndex));
        if (isDirectory(filepath)) {
            System.out.println("  This is a folder!");
            return;
        }

        UtilsGovnokod.analyzeFilePropertiesGovnokod(filepath);
    }

    static void searchInFile(Scanner scanner, String editorBuffer, List<String> searchResults) {
        System.out.print("\n  Enter search query: ");
        String query = scanner.nextLine();

        SearchEngineGovnokod.searchInFileGovnokod(editorBuffer, query, searchResults);
    }

    private static int getFileChoice(Scanner scanner, String prompt, List<String> currentFiles) {
        System.out.print("\n  " + prompt);
        try {
            int choice = Integer.parseInt(scanner.nextLine());
            if (choice < 1 || choice > currentFiles.size()) {
                System.out.println("  Invalid choice!");
                return -1;
            }
            return choice - 1;
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    private static String buildFilePath(String currentDirectory, String filename) {
        return currentDirectory + File.separator + filename;
    }

    private static boolean isDirectory(String path) {
        return new File(path).isDirectory();
    }

    private static void waitForEnter(Scanner scanner) {
        System.out.print("\n  Нажмите Enter для продолжения...");
        scanner.nextLine();
    }

    private static void clearScreen() {
        System.out.print("\033[H\033[2J");
        System.out.flush();
    }

    private static void displayExitMessage() {
        clearScreen();
        System.out.println("\n\n");
        UIHelperGovnokod.printBorder("ВЫХОД");
        System.out.println("  Спасибо за использование Грязного Редактора!");
        System.out.println("  До свидания!");
        UIHelperGovnokod.printBorder("");
        System.out.println("\n\n");
    }
}